from app import api

from flask_restx import fields

course_completion_serializer = api.model("Progress Serializer", {
    "user_id":   fields.Integer(required=True),
    "course_id": fields.Integer(required=True),
    "status":    fields.Integer(required=True),
    "start_date": fields.String(required=True),
    "end_date": fields.String(required=True),
})

user_serializer_in = api.model("User In Model", {
    "id": fields.Integer(readonly=True),
    "username": fields.String(required=True),
    "password": fields.String,
    "name": fields.String(required=True),
    "group_id": fields.Integer(required=True),
})

phase_serializer_out = api.model("Phase Out Serializer", {
    "id": fields.Integer(readonly=True),
    "name": fields.String(required=True),
})

course_serializer_out = api.model("Course Out Serializer", {
    "id": fields.Integer(readonly=True),
    "course_title": fields.String(required=True),
    "course_duration": fields.Integer(required=True),
    "phase": fields.Nested(phase_serializer_out, readonly=True)
})

group_serializer_user = api.model("Group Model Out", {
    "id": fields.Integer(readonly=True),
    "name": fields.String(required=True),
})

user_serializer_out = api.model("User Out Model", {
    "id": fields.Integer(readonly=True),
    "username": fields.String(required=True),
    "name": fields.String(required=True),
    "group_id": fields.Integer(required=True),
    "group" : fields.Nested(group_serializer_user, readonly=True),
    # "tagged_courses": fields.List(fields.Nested(course_completion_serializer_out), readonly=True) 
})

course_completion_serializer_out = api.model("Progress Out Serializer", {
    "user": fields.Nested(user_serializer_out, readonly=True),
    "course": fields.Nested(course_serializer_out, readonly=True),
    "status": fields.Integer(required=True),
    "start_date": fields.String,
    "end_date": fields.String,
})

group_serializer = api.model("Group Model", {
    "id": fields.Integer(readonly=True),
    "wave_id": fields.String(required=True),
    "name": fields.String(required=True),
    "members": fields.List(fields.Nested(user_serializer_out), readonly=True),
    "business_tower":fields.String(required=True),
    "sub_business_group":fields.String(required=True),
    "account_owner_name":fields.String(required=True),
    "account_emp_id":fields.String(required=True),
    "customer_geography":fields.String(required=True),
    "customer_region":fields.String(required=True),
    "infra_readiness":fields.String,
    "infra_comments":fields.String(required=False),
    "software_readiness":fields.String,
    "software_comments":fields.String(required=False),   
    "poc_identification":fields.String,
    "use_case_tech":fields.String(required=False),
    "use_case_name":fields.String(required=False),
    "use_case_description":fields.String(required=False),
    "use_case_customer_ask":fields.String,
})

wave_serializer = api.model("Wave Serializer", {
    "id": fields.Integer(readonly=True),
    "name": fields.String(required=True),
    "groups": fields.List(fields.Nested(group_serializer), readonly=True)
})

course_serializer = api.model("Course Serializer", {
    "id": fields.Integer(readonly=True),
    "course_title": fields.String(required=True),
    "course_duration": fields.Integer(required=True),
    "phase_id": fields.Integer(required=True)
})

phase_serializer = api.model("Phase Serializer", {
    "id": fields.Integer(readonly=True),
    "name": fields.String(required=True),
    "courses": fields.List(fields.Nested(course_serializer), readonly=True)
})
from app import db
import enum


class GroupCoach(db.Model):
    
    __tablename__ = "groupcoach"
    
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey("group.id"))
    group    = db.relationship("Group",  back_populates="coaches")
    
    coach_id   = db.Column(db.Integer, db.ForeignKey("user.id"))
    coach      = db.relationship("User",  back_populates="coach")


class User(db.Model):
    
    __tablename__ = "user"
    
    id         = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.String(100), unique=True, nullable=False)
    name       = db.Column(db.String(100), nullable=False)
    group_id   = db.Column(db.Integer, db.ForeignKey("group.id"))
    group      = db.relationship("Group",  back_populates="members")
    tagged_courses = db.relationship("CourseCompletionMapping", back_populates="user")
    coach = db.relationship("GroupCoach", back_populates="coach")
    
    
class Group(db.Model):
    
    __tablename__ = "group"
    
    id      = db.Column(db.Integer, primary_key=True)
    name    = db.Column(db.String(100), unique=True, nullable=False)
    members = db.relationship("User", back_populates="group")
    team_password   = db.Column(db.String(100))
    
    coaches = db.relationship("GroupCoach", back_populates="group")
    
    business_tower = db.Column(db.String(120), nullable=False)
    sub_business_group = db.Column(db.String(120), nullable=False)
    account_owner_name = db.Column(db.String(120), nullable=False)
    account_emp_id = db.Column(db.String(120), nullable=False)
    customer_geography = db.Column(db.String(120), nullable=False) 
    customer_region = db.Column(db.String(120), nullable=False) 
    infra_readiness = db.Column(db.String(100))
    infra_comments = db.Column(db.String(200))
    software_readiness = db.Column(db.String(100))
    software_comments = db.Column(db.String(200))    
    poc_identification = db.Column(db.String(100))
    use_case_tech = db.Column(db.String(500))
    use_case_name = db.Column(db.String(500))
    use_case_description = db.Column(db.String(2000))
    use_case_customer_ask = db.Column(db.String(100))  
    
    wave_id   = db.Column(db.Integer, db.ForeignKey("wave.id"))
    wave      = db.relationship("Wave",  back_populates="groups")
    

class Wave(db.Model):
    
    __tablename__ = "wave"
    
    id    = db.Column(db.Integer, primary_key=True)
    name  = db.Column(db.String(100), unique=True, nullable=False)
    
    groups = db.relationship("Group",  back_populates="wave")


class Phase(db.Model):
    
    __tablename__ = "phase"
    
    id   = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    courses = db.relationship("Course", back_populates="phase")


class Course(db.Model):
    
    __tablename__ = "course"
    
    id              = db.Column(db.Integer, primary_key=True)
    course_title    = db.Column(db.String(100), unique=True, nullable=False)
    course_duration = db.Column(db.Integer, nullable=False)
    phase_id        = db.Column(db.Integer, db.ForeignKey("phase.id"))
    phase           = db.relationship("Phase",  back_populates="courses")
    tagged_courses  = db.relationship("CourseCompletionMapping", back_populates="course")
    

class CourseCompletionMapping(db.Model):
    
    __tablename__ = "coursecompletionmapping"
    
    id              = db.Column(db.Integer, primary_key=True)
    
    course_id = db.Column(db.Integer, db.ForeignKey("course.id"))
    course    = db.relationship("Course", back_populates="tagged_courses")
    
    user_id   = db.Column(db.Integer, db.ForeignKey("user.id"))
    user      = db.relationship("User", back_populates="tagged_courses")
    
    start_date = db.Column(db.String)
    end_date   = db.Column(db.String)
    
    status    = db.Column(db.Integer)
    
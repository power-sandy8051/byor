# pip install flask
from flask import Flask, abort, jsonify, make_response, request, render_template, send_from_directory

import os

import json

app = Flask(__name__)

# Serve React App
@app.route('/')
def serve():
    return render_template('index.html')

@app.errorhandler(404)
def handle_404(e):
    return render_template('index.html')


# pip install flask-restx
from flask_restx import Api, Resource, reqparse, inputs, marshal_with

# pip install flask-sqlalchemy

# db_connection_string = 'sqlite:///restdb.db'

db_connection_string = "postgresql://postgres:postgres@localhost:5432/byordb"

app.config["SQLALCHEMY_DATABASE_URI"] = db_connection_string

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy(app)

from models import User, Group, Phase, Course, CourseCompletionMapping, GroupCoach, Wave

with app.app_context():
    db.create_all()

# pip install flask-migrate

from flask_migrate import Migrate

migrate = Migrate(app, db)

# pip install flask-jwt-extended

from flask_jwt_extended import JWTManager, create_access_token, jwt_required, set_access_cookies, get_jwt_identity, get_jwt

from datetime import timedelta, datetime, timezone

app.config["SECRET_KEY"]     = 'this is a key'
app.config["JWT_SECRET_KEY"] = 'this is a key'
app.config["JWT_COOKIE_SECURE"] = False
app.config["JWT_TOKEN_LOCATION"] = ["cookies"]
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1)

jwt = JWTManager(app)

api = Api(app, doc="/doc/")

app.config['CORS_HEADERS'] = 'Content-Type'
app.config["CORS_SUPPORTS_CREDENTIALS"] = True

from flask_cors import CORS, cross_origin

CORS(app, supports_credentials=True, resources={r"/*": {"origins": "*"}})

from serializers import user_serializer_in, user_serializer_out, group_serializer, phase_serializer, course_serializer, course_completion_serializer, wave_serializer, course_completion_serializer_out

group_namespace     = api.namespace("groups",  "Groups API")
user_namespace      = api.namespace("users",   "Users  API")
auth_namespace      = api.namespace("auth",    "Auth  API")
phase_namespace     = api.namespace("phases",  "Phases API")
wave_namespace      = api.namespace("waves",   "Waves API")
course_namespace    = api.namespace("courses", "Courses API")
progress_namespace  = api.namespace("progress","Progress API")


@app.route("/me")
@cross_origin()
@jwt_required()
def me():
    group_name = get_jwt_identity()
    return {"group_name": group_name}, 200


@app.route("/login", methods=["POST"])
@cross_origin()
def login():
    data  = json.loads(request.data)
    group = db.session.query(Group).filter_by(name=data["name"]).first()
    if group:
        access_token = create_access_token(identity=group.name)
        response = jsonify({"token": access_token})
        response.headers.add('Set-Cookie', f'access_token_cookie={access_token}; SameSite=None; Secure')
        return response
    else:
        abort(400, f"[ERROR OCCURED] {'Group not Found!'}")
        

@app.route("/logout")
@cross_origin()
def logout():
        response = jsonify({"message": "ok"})
        response.headers.add('Set-Cookie', f'access_token_cookie=null; SameSite=None; Secure')
        return response

# @auth_namespace.route("/")
# class AuthResource(Resource):
    
#     @auth_namespace.expect(user_serializer_in)
#     @auth_namespace.marshal_with(user_serializer_out)
#     def post(self):
#         '''
#             Verifies if the user is valid
#         '''
#         parser = reqparse.RequestParser()
#         parser.add_argument("group_name")
#         parser.add_argument("password")
#         data = parser.parse_args()
        
#         user = db.session.query(User).filter_by(username=data["group_name"], password=data["group_name"]).first()
#         if user:
#             return '', 200
        
#         else:
#             abort(400, f"[ERROR OCCURED] {'User not Found!'}")


@user_namespace.route("/")
class UserResource(Resource):
    
    @user_namespace.expect(user_serializer_in)
    @user_namespace.marshal_with(user_serializer_out)
    def post(self):
        '''
        Creates a User Profile
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("username")
        parser.add_argument("name")
        parser.add_argument("group_id")
        data = parser.parse_args()
        
        try:        
            user = User(username=data["username"], name=data["name"], group_id=data["group_id"])
            db.session.add(user)
            db.session.commit()
            return user
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


    @user_namespace.marshal_with(user_serializer_out, envelope='users')
    def get(self):
        '''
            Lists all the users
        '''
        try:        
            users = db.session.query(User).all()
            for user in users:
                print(user.tagged_courses)
            return users
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@user_namespace.route("/<int:id>")
class UserResourceWithId(Resource):

    @user_namespace.marshal_with(user_serializer_out)
    def get(self, id):
        '''
            Get the user with Id
        '''       
        user = db.session.query(User).filter_by(id=id).all()
        if user:
            return user
        else:
            abort(400, f"[ERROR OCCURED] User Not Found!")    


    @user_namespace.marshal_with(user_serializer_out)
    def put(self, id):
        '''
            Edit the user with Id
        '''       
        user = db.session.query(User).filter_by(id=id).first()
        if user:
            data = json.loads(request.data)
            for key in data:
                setattr(user, key, data[key])
            db.session.add(user)
            db.session.commit()
            return user, 200
        else:
            abort(400, f"[ERROR OCCURED] User Not Found!")
          
          
    @user_namespace.marshal_with(user_serializer_out)
    def delete(self, id):
        '''
            Delete the user with Id
        '''       
        user = db.session.query(User).filter_by(id=id).all()
        if user:
            db.session.query(User).filter_by(id=id).delete()
            db.session.commit()
            return '', 204
        else:
            abort(400, f"[ERROR OCCURED] User Not Found!")            

      
@group_namespace.route("/")
class GroupResource(Resource):
    
    @group_namespace.expect(group_serializer)
    @group_namespace.marshal_with(group_serializer)
    def post(self):
        '''
            Creates a Group
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("name")
        parser.add_argument("business_tower")
        parser.add_argument("sub_business_group")
        parser.add_argument("account_owner_name")
        parser.add_argument("account_emp_id")
        parser.add_argument("customer_geography")
        parser.add_argument("customer_region")
        parser.add_argument("infra_readiness")
        parser.add_argument("infra_comments")
        parser.add_argument("software_readiness")
        parser.add_argument("software_comments")
        parser.add_argument("software_readiness")
        parser.add_argument("poc_identification")
        parser.add_argument("use_case_tech")
        parser.add_argument("use_case_name")
        parser.add_argument("use_case_description")
        parser.add_argument("use_case_customer_ask")
        parser.add_argument("password")
        parser.add_argument("wave_id", type=int)       

        data = parser.parse_args()

        try:        
            group = Group(
                            name=data["name"],
                            business_tower=data["business_tower"],
                            sub_business_group = data["sub_business_group"],
                            account_owner_name = data["account_owner_name"],
                            account_emp_id = data["account_emp_id"],
                            customer_geography = data["customer_geography"],
                            customer_region = data["customer_region"],
                            infra_readiness = data["infra_readiness"],
                            infra_comments = data["infra_comments"],
                            software_readiness = data["software_readiness"],
                            software_comments = data["software_comments"],
                            poc_identification = data["poc_identification"],
                            use_case_tech = data["use_case_tech"],
                            use_case_name = data["use_case_name"],
                            use_case_description = data["use_case_description"],
                            use_case_customer_ask = data["use_case_customer_ask"],
                            wave_id = data["wave_id"],
                            team_password = data["password"]
                        )
            
            db.session.add(group)
            db.session.commit()
            return group
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")
            

    @group_namespace.marshal_with(group_serializer, envelope='groups')
    def get(self):
        '''
            Lists all the Groups and their members
        '''
        try:        
            groups = db.session.query(Group).all()
            # [print(g, g.coaches) for g in groups]
            return groups
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@group_namespace.route("/<int:id>")
class GroupResourceWithParam(Resource):
    
    @group_namespace.marshal_with(group_serializer)
    def get(self, id):
        '''
            Gets the Group with Specific Id
        '''
      
        group = db.session.query(Group).filter_by(id=id).first()
        if group:
            return group
        else:        
            abort(400, f"[ERROR OCCURED] Group Not Found!")

    
    @group_namespace.expect(group_serializer)
    @group_namespace.marshal_with(group_serializer)
    def put(self, id):
        '''
            Updates the Group name
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("name")
        data = json.loads(request.data)
      
        group = db.session.query(Group).filter_by(id=id).first()
        if group:
            try:        
                for key in data:
                    setattr(group, key, data[key])
                db.session.add(group)
                db.session.commit()
                return group
            
            except Exception as e:
                print(e)
                abort(400, f"[ERROR OCCURED] {e}")
        else:        
            abort(400, f"[ERROR OCCURED] Group Not Found!")


@phase_namespace.route("/")
class PhaseResource(Resource):
    
    @phase_namespace.expect(phase_serializer)
    @phase_namespace.marshal_with(phase_serializer)
    def post(self):
        '''
            Creates a Phase
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("name")
        data = parser.parse_args()

        try:        
            phase = Phase(name=data["name"])
            db.session.add(phase)
            db.session.commit()
            return phase
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")
            

    @phase_namespace.marshal_with(phase_serializer, envelope='phases')
    def get(self):
        '''
            Lists all the Phases and their respective courses
        '''
        try:        
            phases = db.session.query(Phase).all()
            return phases
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")

  
@wave_namespace.route("/")
class WaveResource(Resource):
    
    @wave_namespace.expect(wave_serializer)
    @wave_namespace.marshal_with(wave_serializer)
    def post(self):
        '''
            Creates a Wave
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("name")
        data = parser.parse_args()

        try:        
            wave = Wave(name=data["name"])
            db.session.add(wave)
            db.session.commit()
            return wave
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")
            

    @wave_namespace.marshal_with(wave_serializer, envelope='waves')
    def get(self):
        '''
            Lists all the Waves and their respective groups
        '''
        try:        
            waves = db.session.query(Wave).all()
            return waves
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@phase_namespace.route("/<int:id>")
class PhaseResourceWithId(Resource):

    @phase_namespace.marshal_with(phase_serializer)
    def get(self, id):
        '''
            Get a phase by given id & its respective courses
        '''
        try:        
            phases = db.session.query(Phase).filter_by(id=id).all()
            return phases
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@course_namespace.route("/")
class CourseResource(Resource):
    
    @course_namespace.expect(course_serializer)
    @course_namespace.marshal_with(course_serializer)
    def post(self):
        '''
            Creates a Course
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("course_duration")
        parser.add_argument("course_title")
        parser.add_argument("phase_id")
        data = parser.parse_args()

        try:        
            course = Course(course_title=data["course_title"], course_duration=data["course_duration"], phase_id=data["phase_id"])
            db.session.add(course)
            db.session.commit()
            return course
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@course_namespace.route("/<int:id>")
class CourseResourceWithId(Resource):
    
    @course_namespace.marshal_with(course_serializer)
    def get(self, id):
        '''
            Gets a Course with ID
        '''     
        course = db.session.query(Course).filter_by(id=id).first()
        if course:
            return course, 200
        else:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@progress_namespace.route("/")
class CourseProgressUpdate(Resource):
    
    @progress_namespace.expect(course_completion_serializer)
    @progress_namespace.marshal_with(course_completion_serializer_out)
    def post(self):
        '''
            Updates Progress for a User for Specific Course
        '''
        
        parser = reqparse.RequestParser()
        parser.add_argument("course_id")
        parser.add_argument("user_id")
        parser.add_argument("status")
        parser.add_argument("start_date")
        parser.add_argument("end_date")
        data = parser.parse_args()

        try:        
            ccm = db.session.query(CourseCompletionMapping).filter_by(course_id=data["course_id"], user_id=data["user_id"]).first()
            if ccm:
                for key in data:
                    setattr(ccm, key, data[key])
            else:
                ccm = CourseCompletionMapping(course_id=data["course_id"], user_id=data["user_id"], status=data["status"], start_date=data["start_date"], end_date=data["end_date"])
            db.session.add(ccm)
            db.session.commit()
            return ccm
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


    @progress_namespace.marshal_with(course_completion_serializer_out)
    def put(self):
        '''
            Lists Progress for a all Users of a Group
        '''
        parser = reqparse.RequestParser()
        parser.add_argument("group_id")  
        data = parser.parse_args()      
        group_id = data["group_id"]
        try:        
            if group_id:
                ccm = db.session.query(CourseCompletionMapping).join(User).filter(User.group_id == group_id).all()
            else:
                ccm = db.session.query(CourseCompletionMapping).all()
            return ccm
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")
            

    @progress_namespace.expect(course_completion_serializer)
    def delete(self):
        '''
            Deletes Progress for a User for Specific Course
        '''
        
        parser = reqparse.RequestParser()
        parser.add_argument("course_id")
        parser.add_argument("user_id")
        data = parser.parse_args()

        c = db.session.query(CourseCompletionMapping).filter_by(course_id=data["course_id"], user_id=data["user_id"]).delete()
        db.session.commit()
        return '', 204      


@progress_namespace.route("/<int:id>")
class CourseProgressUpdateWithId(Resource):
    
    @progress_namespace.marshal_with(course_completion_serializer_out)
    def get(self, id):
        '''
            Lists Progress for a User
        '''

        try:        
            ccm = db.session.query(CourseCompletionMapping).filter_by(user_id=id).all()
            return ccm
        
        except Exception as e:
            print(e)
            abort(400, f"[ERROR OCCURED] {e}")


@app.after_request
def refresh_expiring_jwts(response):
    try:
        exp_timestamp = get_jwt()["exp"]
        now = datetime.now(timezone.utc)
        target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
        access_token = create_access_token(identity=get_jwt_identity())
        response.headers.add('Set-Cookie', f'access_token_cookie={access_token}; SameSite=None; Secure')
        return response
    
    except (RuntimeError, KeyError):
        return response